# Login-Plano-Moderno-Transparente-Placeholder-WinForm-C-Sharp

<h2>Tutorial:</h2>
<h3>Blog:</h3>
https://rjcodeadvance.com/cap-1-disenar-login-moderno-efecto-placeholder-y-transparencia-c-y-winform/
<h3>YouTube:</h3>
https://www.youtube.com/watch?v=en_eqatpDEo
<img src="https://rjcodeadvance.com/wp-content/uploads/2019/08/Login-Disign-2.png">
